Oduda - rounded typeface is the first font created by thmbnl. graphic design. This bold version of Oduda is free of use for personal and commercial projects.

http://www.behance.net/thmbnl-team
